package com.dzlin.springboothello.controller;

import com.dzlin.springboothello.entity.UserEntity;
import com.dzlin.springboothello.mapper.UserMapper;
import com.dzlin.springboothello.payload.InsertUserRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value = "/user")
public class UserController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private UserMapper userMapper;

    @Autowired
    public UserController(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @GetMapping(value = "/delete")
    public void delete() {
        Long n = this.userMapper.delete(1L);
        this.logger.info("delete: " + n);
    }

    @GetMapping(value = "/update")
    public void update() {
        Long n = this.userMapper.update(new UserEntity(300L, "wangwu2@163.com", "王五2"));
        this.logger.info("update: " + n);
    }

    @PostMapping(value = "/add")
    public UserEntity insert(@Valid @RequestBody InsertUserRequest payload) {
        UserEntity userEntity = new UserEntity(payload.getEmail(), payload.getName());
        if (this.userMapper.insert(userEntity) == 1 && userEntity.getId() > 0) {
            return userEntity;
        }
        return new UserEntity();
    }

    @GetMapping(value = "/{id}")
    public UserEntity getOne(@PathVariable("id") Long id) {
        return this.userMapper.getOne(id);
    }

    @GetMapping(value = "/getAll")
    public List<UserEntity> getAll() {
        return this.userMapper.getAll();
    }
}
