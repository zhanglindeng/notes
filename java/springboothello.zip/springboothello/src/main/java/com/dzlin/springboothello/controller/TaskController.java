package com.dzlin.springboothello.controller;

import com.dzlin.springboothello.task.DemoTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Future;

@RestController
@RequestMapping(value = "/task")
public class TaskController {

    private DemoTask demoTask;

    @Autowired
    public TaskController(DemoTask demoTask) {
        this.demoTask = demoTask;
    }

    @GetMapping(value = "/task1")
    public String task1() {
        try {
            Future<Boolean> future = this.demoTask.task1();

//            future.isDone();
            return "success";

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "failed";
    }
}
