package com.dzlin.springboothello.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class Task1 {

    private Logger logger = LoggerFactory.getLogger(Task1.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");

    // @link https://blog.csdn.net/ninifengs/article/details/77141240
    // 每 10 秒执行一次
//    @Scheduled(fixedRate = 10000)
    // 每 6 秒执行一次
    @Scheduled(cron = "*/6 * * * * ?")
    public void run() {
        logger.info("现在时间：" + dateFormat.format(new Date()));
    }
}
