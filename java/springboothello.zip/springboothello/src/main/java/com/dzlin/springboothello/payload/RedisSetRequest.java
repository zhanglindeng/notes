package com.dzlin.springboothello.payload;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RedisSetRequest {

    @NotBlank
    @Size(min = 1, max = 30)
    private String key;

    @NotBlank
    @Size(max = 100)
    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
