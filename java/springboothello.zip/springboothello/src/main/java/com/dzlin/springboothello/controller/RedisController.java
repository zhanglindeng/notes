package com.dzlin.springboothello.controller;

import com.alibaba.fastjson.JSONObject;
import com.dzlin.springboothello.payload.RedisSetRequest;
import com.dzlin.springboothello.util.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "/redis")
public class RedisController {

    private RedisUtil redisUtil;

    @Autowired
    public RedisController(RedisUtil redisUtil) {
        this.redisUtil = redisUtil;
    }

    @PostMapping(value = "/expire")
    public JSONObject expire(@Valid @RequestBody RedisSetRequest payload) {
        JSONObject jsonObject = new JSONObject();

        redisUtil.set(payload.getKey(), payload.getValue(), 60L);

        jsonObject.put("code", 0);
        jsonObject.put("message", "OK");

        return jsonObject;
    }

    @PostMapping(value = "/set")
    public JSONObject set(@Valid @RequestBody RedisSetRequest payload) {
        JSONObject jsonObject = new JSONObject();

        redisUtil.set(payload.getKey(), payload.getValue());

        jsonObject.put("code", 0);
        jsonObject.put("message", "OK");

        return jsonObject;
    }

    @GetMapping(value = "/get")
    public String get(@RequestParam String key) {
        return redisUtil.get(key);
    }

    @GetMapping(value = "/incr")
    public JSONObject incr(@RequestParam String key) {
        JSONObject jsonObject = new JSONObject();

        Long result = redisUtil.increment(key, 1L);

        jsonObject.put("code", 0);
        jsonObject.put("data", result);
        jsonObject.put("message", "OK");

        return jsonObject;
    }

    @GetMapping(value = "/del")
    public JSONObject del(@RequestParam String key) {
        JSONObject jsonObject = new JSONObject();

        Integer code = 1;
        String message = "failed";
        if (redisUtil.del(key)) {
            code = 0;
            message = "OK";
        }

        jsonObject.put("code", code);
        jsonObject.put("message", message);

        return jsonObject;
    }
}
