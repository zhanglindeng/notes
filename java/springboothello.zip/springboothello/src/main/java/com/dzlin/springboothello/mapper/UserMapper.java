package com.dzlin.springboothello.mapper;

import com.dzlin.springboothello.entity.UserEntity;
import org.springframework.stereotype.Component;

import java.util.List;

// 不加 @Component 也可以，不过 idea @Autowired 提示错误
@Component
public interface UserMapper {
    List<UserEntity> getAll();

    UserEntity getOne(Long id);

    // 返回添加成功的行数
    Long insert(UserEntity user);

    // 返回受影响的行数，貌似不准确，数据没有更改也一样返回1
    Long update(UserEntity user);

    // 返回被删除的行数
    Long delete(Long id);
}
