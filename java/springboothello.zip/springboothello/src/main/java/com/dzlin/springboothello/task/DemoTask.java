package com.dzlin.springboothello.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.Future;

@Component
public class DemoTask {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Async
    public Future<Boolean> task1() throws InterruptedException {
        // 响应后还是可以继续执行
        Long start = System.currentTimeMillis();
        Thread.sleep(3000);
        logger.info("消耗时间：" + (System.currentTimeMillis() - start));
        return new AsyncResult<>(true);
    }
}
