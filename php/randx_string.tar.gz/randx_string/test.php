<?php
echo randx_string(10).PHP_EOL;
